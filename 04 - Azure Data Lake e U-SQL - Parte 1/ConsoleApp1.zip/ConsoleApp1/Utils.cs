﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Rest;
using Microsoft.Rest.Azure.Authentication;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Utils
    {

        public static TokenCache GetTokenCache(string path)
        {
            var tokenCache = new TokenCache();

            tokenCache.BeforeAccess += notificationArgs =>
            {
                if (File.Exists(path))
                {
                    var bytes = File.ReadAllBytes(path);
                    notificationArgs.TokenCache.Deserialize(bytes);
                }
            };

            tokenCache.AfterAccess += notificationArgs =>
            {
                var bytes = notificationArgs.TokenCache.Serialize();
                File.WriteAllBytes(path, bytes);
            };
            return tokenCache;
        }


        public static ServiceClientCredentials GetCreds_User_Popup(
           string tenant,
           System.Uri tokenAudience,
           string clientId,
           TokenCache tokenCache,
           PromptBehavior promptBehavior = PromptBehavior.Auto)
        {
            SynchronizationContext.SetSynchronizationContext(new SynchronizationContext());

            var clientSettings = new ActiveDirectoryClientSettings
            {
                ClientId = clientId,
                ClientRedirectUri = new System.Uri("urn:ietf:wg:oauth:2.0:oob"),
                PromptBehavior = promptBehavior
            };

            var serviceSettings = ActiveDirectoryServiceSettings.Azure;
            serviceSettings.TokenAudience = tokenAudience;

            var creds = UserTokenProvider.LoginWithPromptAsync(
               tenant,
               clientSettings,
               serviceSettings,
               tokenCache).GetAwaiter().GetResult();
            return creds;
        }

        public static ServiceClientCredentials GetCreds_SPI_SecretKey(
           string tenant,
           Uri tokenAudience,
           string clientId,
           string secretKey)
        {
            SynchronizationContext.SetSynchronizationContext(new SynchronizationContext());

            var serviceSettings = ActiveDirectoryServiceSettings.Azure;
            serviceSettings.TokenAudience = tokenAudience;

            var creds = ApplicationTokenProvider.LoginSilentAsync(
             tenant,
             clientId,
             secretKey,
             serviceSettings).GetAwaiter().GetResult();
            return creds;
        }

        public static ServiceClientCredentials GetCreds_SPI_Cert(
           string tenant,
           Uri tokenAudience,
           string clientId,
           X509Certificate2 certificate)
        {
            SynchronizationContext.SetSynchronizationContext(new SynchronizationContext());

            var clientAssertionCertificate = new ClientAssertionCertificate(clientId, certificate);
            var serviceSettings = ActiveDirectoryServiceSettings.Azure;
            serviceSettings.TokenAudience = tokenAudience;

            var creds = ApplicationTokenProvider.LoginSilentWithCertificateAsync(
                tenant,
                clientAssertionCertificate,
                serviceSettings).GetAwaiter().GetResult();
            return creds;
        }

    }
}
