﻿using System;
using System.IO;
using System.Threading;
using System.Security.Cryptography.X509Certificates;

using Microsoft.Rest;
using Microsoft.Rest.Azure.Authentication;
using Microsoft.Azure.Management.DataLake.Analytics;
using Microsoft.Azure.Management.DataLake.Analytics.Models;
using Microsoft.Azure.Management.DataLake.Store;
using Microsoft.Azure.Management.DataLake.Store.Models;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string TENANT = "INSIRA_SEU_VALOR_AQUI";
            string CLIENTID = "1950a258-227b-4e31-a9cf-717495945fc2";
            Uri ARM_TOKEN_AUDIENCE = new System.Uri(@"https://management.core.windows.net/");
            Uri ADL_TOKEN_AUDIENCE = new System.Uri(@"https://datalake.azure.net/");
            Uri GRAPH_TOKEN_AUDIENCE = new System.Uri(@"https://graph.windows.net/");

            string SUBSCRIPTION_ID = "INSIRA_SEU_VALOR_AQUI";
            string RESOURCE_GROUP = "Capitulo04"; // Altere esta valor se for o caso
            string ADLA = "datascienceacademy";   // Altere este valor se for o caso
            string ADLS = "datascienceacademy";   // Altere este valor se for o caso

            string MY_DOCUMENTS = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
            string TOKEN_CACHE_PATH = System.IO.Path.Combine(MY_DOCUMENTS, "my.tokencache");

            var tokenCache = Utils.GetTokenCache(TOKEN_CACHE_PATH);
            var armCreds = Utils.GetCreds_User_Popup(TENANT, ARM_TOKEN_AUDIENCE, CLIENTID, tokenCache);
            var adlCreds = Utils.GetCreds_User_Popup(TENANT, ADL_TOKEN_AUDIENCE, CLIENTID, tokenCache);
            var graphCreds = Utils.GetCreds_User_Popup(TENANT, GRAPH_TOKEN_AUDIENCE, CLIENTID, tokenCache);

            // Clients
            var adlsClient = new DataLakeStoreAccountManagementClient(armCreds) { SubscriptionId = SUBSCRIPTION_ID };
            var adlaClient = new DataLakeAnalyticsAccountManagementClient(armCreds) { SubscriptionId = SUBSCRIPTION_ID };
            var adlaJobClient = new DataLakeAnalyticsJobManagementClient(adlCreds);

            var adla_resource = adlaClient.Account.Get(RESOURCE_GROUP, ADLA);
            var adls_resource = adlsClient.Account.Get(RESOURCE_GROUP, ADLS);

            var script = File.ReadAllText("..\\..\\script.txt");

            var jobName = "Job .NET SDK";
            var jobId = Guid.NewGuid();
            var properties = new USqlJobProperties(script);
            var parameters = new JobInformation(jobName, JobType.USql, properties, priority: 1, degreeOfParallelism: 1, jobId: jobId);
            var jobInfo = adlaJobClient.Job.Create(ADLA, jobId, parameters);

            Console.WriteLine($"Job {jobName} enviado.");

            Console.WriteLine("FIM");
            Console.ReadKey();
        }
    }
}
