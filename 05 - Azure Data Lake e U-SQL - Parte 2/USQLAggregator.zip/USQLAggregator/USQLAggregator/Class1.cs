﻿using Microsoft.Analytics.Interfaces;
using Microsoft.Analytics.Interfaces.Streaming;
using Microsoft.Analytics.Types.Sql;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace USQLAggregator
{
    public class Quadrado : IAggregate<int, long>
    {
        long total;

        public override void Accumulate(int t1)
        {
            total = total + (t1 * t1);
        }

        public override void Init()
        {
            total = 0;
        }

        public override long Terminate()
        {
            return total;
        }
    }
}