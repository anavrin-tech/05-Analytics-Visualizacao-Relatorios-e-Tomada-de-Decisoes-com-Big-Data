﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AzureSQLDW_VS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Lembre-se de colocar na String de Conexão o nome de usuário e senha para conexão
            var connectionString = "COLOQUE_SUA_STRING_DE_CONEXAO_AQUI";

            var sql = "select * from FactInternetSales where UnitPrice > 3000";

            var conn = new SqlConnection(connectionString);

            var cmd = new SqlCommand(sql, conn);

            conn.Open();

            var dr = cmd.ExecuteReader();

            var dt = new DataTable();
            dt.Load(dr);
            dgv.DataSource = dt;
            conn.Close();
            MessageBox.Show("Processamento terminou");
        }
    }
}
